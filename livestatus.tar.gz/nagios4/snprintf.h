/* lib/snprintf.h.  Generated from snprintf.h.in by configure.  */
/* -*- C -*- */
#ifndef LIBNAGIOS_snprintf_h__
#define LIBNAGIOS_snprintf_h__
/* #undef HAVE_SNPRINTF */
/* #undef NEED_VA_LIST */
#endif
